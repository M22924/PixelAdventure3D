using UnityEngine;
public class ThirdPersonCamera:MonoBehaviour
{
 public Transform target; public float distance=6f,height=3f,sensitivity=3f; float yaw=0,pitch=18;
 void LateUpdate(){if(!target)return;if(Input.GetMouseButton(2)||Input.GetMouseButton(1)){yaw+=Input.GetAxis("Mouse X")*sensitivity;pitch-=Input.GetAxis("Mouse Y")*sensitivity;pitch=Mathf.Clamp(pitch,-5,55);} Quaternion r=Quaternion.Euler(pitch,yaw,0);Vector3 pos=target.position+r*new Vector3(0,height,-distance);transform.position=Vector3.Lerp(transform.position,pos,12*Time.deltaTime);transform.LookAt(target.position+Vector3.up*1.2f);}
}
