PIXEL ADVENTURE 3D - UNITY STARTER

This is a clean Unity 3D starter migration based on the uploaded Java Pixel Adventure design.

WHAT IS INCLUDED
- Third-person 3D player movement
- Camera follow/orbit
- Jump + gravity
- Sword melee attack
- Fireball ranged attack
- Enemy chase + attack
- Health system
- Mission objective system: COMBAT / RESCUE / COLLECT
- Easy / Medium / Hard campaign data
- 15+boss / 15+boss / 10+boss structure
- Boss dialogue data for Ritchter, Torres, Jerimy
- Mission progression
- Simple 3D scene bootstrap using primitives (no external assets required)

UNITY SETUP
1. Create a new Unity 3D project (Built-in Render Pipeline is fine).
2. Close Unity.
3. Copy the Assets folder from this package into the Unity project, replacing/merging Assets.
4. Open Unity and open Assets/Scenes/PixelAdventure3D.unity.
5. Press Play.

CONTROLS
WASD = move
Mouse = camera
Space = jump
Left Mouse = sword
Right Mouse = fireball
E = rescue/interact
ESC = pause

NOTE
The starter intentionally uses Unity primitive meshes so it runs without downloaded assets. Replace the placeholder player/enemy models with your animated 3D FBX/GLB models later.
