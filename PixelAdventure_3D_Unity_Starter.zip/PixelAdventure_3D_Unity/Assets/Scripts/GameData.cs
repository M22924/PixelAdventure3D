using System;
using UnityEngine;

public enum DifficultyMode { EASY, MEDIUM, HARD }
public enum StoryObjective { COMBAT, RESCUE, COLLECT }

[Serializable]
public class MissionData
{
    public int number;
    public string title;
    public string region;
    public string brief;
    public StoryObjective objective;
    public bool boss;
    public string bossName;
}

public static class PixelAdventureData
{
    public static int MissionsBeforeBoss(DifficultyMode d) => d == DifficultyMode.HARD ? 10 : 15;
    public static int TotalMissions(DifficultyMode d) => MissionsBeforeBoss(d) + 1;

    public static string BossName(DifficultyMode d) => d == DifficultyMode.EASY ? "Sir Ritchter" : d == DifficultyMode.MEDIUM ? "Sir Torres" : "Sir Jerimy, The Great";

    public static MissionData[] BuildCampaign(DifficultyMode d)
    {
        string[] titles;
        string[] regions;
        string[] briefs;
        StoryObjective[] objectives;
        if (d == DifficultyMode.EASY)
        {
            titles = new[]{"The First Cry","Broken Gates","Rescue at Dawn","Footprints in the Forest","Pendant of Elara","The Whispering Woods","Prisoner in the Ruins","The Hidden Path","A Royal Message","The Silent Bridge","Into the Old Fortress","The Empty Cell","The Royal Seal","The False Prison","The Princess's Choice","Sir Ritchter"};
            regions = new[]{"FOREST","FOREST","FOREST","FOREST","VILLAGE","VILLAGE","VILLAGE","VILLAGE","RIVER","RIVER","MOUNTAIN","MOUNTAIN","DARK RUINS","DARK RUINS","ROYAL CASTLE","BOSS CASTLE"};
            briefs = new[]{"A distress bell rings across the kingdom. Someone is asking for help.","The outer gates have fallen, and villagers are trapped behind the enemy line.","A young royal messenger says Princess Elara was taken toward the forest.","Footprints lead deeper into the forest, but the trail feels strangely deliberate.","You discover a pendant bearing Princess Elara's royal seal.","The forest whispers a warning: the monsters are not acting alone.","A prisoner is being held in ancient ruins. The royal crest is painted on the cell door.","A hidden road points toward an abandoned fortress beyond the river.","A royal message says: Do not trust the first person who asks to be rescued.","The bridge is guarded by creatures that seem to be protecting something, not attacking it.","Inside the old fortress, you find records of a forgotten royal guardian.","The prison cell is empty. Someone escaped before you arrived.","A royal seal reveals that Princess Elara knew about the invasion before it began.","You learn the kingdom built the prison to hide a secret, not simply to hold a prisoner.","Princess Elara finally appears and asks you to stop rescuing her and start saving the kingdom.","Sir Ritchter stands between you and the castle's final gate. He knows where Elara really went."};
            objectives = new[]{StoryObjective.COMBAT,StoryObjective.COMBAT,StoryObjective.RESCUE,StoryObjective.COMBAT,StoryObjective.COLLECT,StoryObjective.COMBAT,StoryObjective.RESCUE,StoryObjective.COMBAT,StoryObjective.COLLECT,StoryObjective.RESCUE,StoryObjective.COMBAT,StoryObjective.RESCUE,StoryObjective.COLLECT,StoryObjective.COMBAT,StoryObjective.RESCUE,StoryObjective.COMBAT};
        }
        else if (d == DifficultyMode.MEDIUM)
        {
            titles = new[]{"Beyond the Border","The Missing Prince","Ashes of the Village","The Royal Artifact","The Knight's Oath","The Captive Guardian","The Broken Banner","The Council's Secret","Torres' Shadow","The Betrayed Guard","The Prison Break","The Corrupted Crystal","The Fallen Order","The Last Witness","The Choice of Torres","Sir Torres"};
            regions = new[]{"VILLAGE","VILLAGE","RIVER","RIVER","FOREST","FOREST","MOUNTAIN","MOUNTAIN","DARK RUINS","DARK RUINS","DARK RUINS","DARK RUINS","ROYAL CASTLE","ROYAL CASTLE","ROYAL CASTLE","BOSS CASTLE"};
            briefs = new[]{"Beyond the first kingdom lies a land where the royal family has vanished.","Prince Adrian has disappeared. The survivors believe he was taken by the Dark Knights.","The village burns, but the attack left no monster tracks. Someone planned this.","A stolen royal artifact is connected to the same seal found in Elara's kingdom.","An old knight claims Sir Torres once protected both kingdoms.","A captive guardian warns that Torres is being controlled by something inside the royal crystal.","The royal banner has been torn in half. One side carries the kingdom's crest; the other carries a strange mark.","The council hid a secret: the crystal was never meant to be used as a weapon.","You see Sir Torres watching from the shadows, but he refuses to attack.","The truth begins to surface: Torres may be a victim of the same corruption he appears to serve.","You break into the prison and find records proving the royal council betrayed its own guardian.","The corrupted crystal is weakening. Someone must decide whether to destroy it or save its host.","The order of knights has fallen, but one witness still remembers what happened before the corruption.","The last witness says Prince Adrian and Elara were working together from the beginning.","Sir Torres offers you a choice: defeat him, or risk everything to free him from the corruption.","Sir Torres is waiting. The real enemy is not the knight—it is the power controlling the realm."};
            objectives = new[]{StoryObjective.COMBAT,StoryObjective.RESCUE,StoryObjective.COMBAT,StoryObjective.COLLECT,StoryObjective.COMBAT,StoryObjective.RESCUE,StoryObjective.COMBAT,StoryObjective.COLLECT,StoryObjective.COMBAT,StoryObjective.COMBAT,StoryObjective.RESCUE,StoryObjective.COLLECT,StoryObjective.COMBAT,StoryObjective.RESCUE,StoryObjective.RESCUE,StoryObjective.COMBAT};
        }
        else
        {
            titles = new[]{"The Fallen Realm","The First Survivor","Echoes of the Past","The Forgotten Road","The Memory Keeper","The Dark Crystal","Voices in the Ruins","The Last Survivors","The Truth Beneath","The Sealed Gate","Sir Jerimy, The Great"};
            regions = new[]{"DARK REALM","DARK REALM","DARK REALM","DARK REALM","DARK REALM","DARK REALM","DARK REALM","DARK REALM","DARK REALM","BOSS APPROACH","BOSS CASTLE"};
            briefs = new[]{"The Dark Realm has fallen silent. Only scattered survivors remain.","A survivor recognizes your hero and says you have saved them before, long ago.","Memories begin returning: you have walked these ruins before.","The road ahead contains symbols that only your hero seems able to understand.","A memory keeper reveals that your memories were sealed on purpose.","The Dark Crystal reacts to your presence as if it recognizes its creator.","Voices in the ruins call you Guardian instead of Hero.","The last survivors reveal that Elara and Adrian were trying to protect you, not the other way around.","A hidden record says the three realms were connected by one ancient seal.","The final gate opens only for the person who sealed it the first time.","Sir Jerimy stands beyond the gate. He is not protecting the enemy—he is protecting the seal from you."};
            objectives = new[]{StoryObjective.COMBAT,StoryObjective.RESCUE,StoryObjective.COLLECT,StoryObjective.COMBAT,StoryObjective.RESCUE,StoryObjective.COLLECT,StoryObjective.COMBAT,StoryObjective.RESCUE,StoryObjective.COLLECT,StoryObjective.RESCUE,StoryObjective.COMBAT};
        }
        MissionData[] result = new MissionData[titles.Length];
        for (int i=0;i<titles.Length;i++) result[i]=new MissionData{number=i+1,title=titles[i],region=regions[i],brief=briefs[i],objective=objectives[i],boss=i==titles.Length-1,bossName=i==titles.Length-1?BossName(d):""};
        return result;
    }
}
