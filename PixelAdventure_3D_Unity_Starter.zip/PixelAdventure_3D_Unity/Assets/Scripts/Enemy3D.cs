using UnityEngine;

public class Enemy3D : MonoBehaviour
{
    public int maxHealth=50; public int health=50; public float chaseRange=10f; public float attackRange=1.7f; public float speed=2.2f; public int damage=10; public float attackCooldown=1.2f; public bool boss;
    Transform player; float nextAttack;
    void Start(){health=maxHealth; GameObject p=GameObject.FindGameObjectWithTag("Player"); if(p)player=p.transform;}
    void Update(){ if(!player)return; float d=Vector3.Distance(transform.position,player.position); if(d<=chaseRange && d>attackRange){Vector3 dir=(player.position-transform.position);dir.y=0;transform.forward=Vector3.Slerp(transform.forward,dir.normalized,6f*Time.deltaTime);transform.position+=transform.forward*speed*Time.deltaTime;} if(d<=attackRange && Time.time>=nextAttack){nextAttack=Time.time+attackCooldown;player.GetComponent<Player3D>()?.TakeDamage(damage);} }
    public void TakeDamage(int amount){health-=amount;if(health<=0){GameObject.FindObjectOfType<MissionManager3D>()?.EnemyDefeated(this);Destroy(gameObject);}}
}
