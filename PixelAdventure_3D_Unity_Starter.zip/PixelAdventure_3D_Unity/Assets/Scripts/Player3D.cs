using UnityEngine;

[RequireComponent(typeof(CharacterController))]
public class Player3D : MonoBehaviour
{
    public float moveSpeed = 5f;
    public float sprintSpeed = 8f;
    public float jumpHeight = 2f;
    public float gravity = -20f;
    public Transform cameraTransform;
    public Transform attackPoint;
    public GameObject fireballPrefab;
    public int maxHealth = 120;
    public int health = 120;
    public int meleeDamage = 28;
    public int fireballDamage = 25;
    public float attackRange = 1.8f;
    public LayerMask enemyLayer;

    CharacterController controller;
    Vector3 velocity;
    float attackCooldown;

    void Awake(){ controller=GetComponent<CharacterController>(); health=maxHealth; }
    void Update()
    {
        Move();
        if(attackCooldown>0) attackCooldown-=Time.deltaTime;
        if(Input.GetMouseButtonDown(0)) Melee();
        if(Input.GetMouseButtonDown(1)) Fireball();
        if(health<=0) Respawn();
    }
    void Move()
    {
        float x=Input.GetAxisRaw("Horizontal"), z=Input.GetAxisRaw("Vertical");
        Vector3 forward=cameraTransform?Vector3.Scale(cameraTransform.forward,new Vector3(1,0,1)).normalized:Vector3.forward;
        Vector3 right=cameraTransform?cameraTransform.right:Vector3.right;
        Vector3 dir=(forward*z+right*x).normalized;
        float speed=Input.GetKey(KeyCode.LeftShift)?sprintSpeed:moveSpeed;
        controller.Move(dir*speed*Time.deltaTime);
        if(dir.sqrMagnitude>.01f) transform.forward=Vector3.Slerp(transform.forward,dir,12f*Time.deltaTime);
        if(controller.isGrounded && velocity.y<0) velocity.y=-2f;
        if(Input.GetKeyDown(KeyCode.Space) && controller.isGrounded) velocity.y=Mathf.Sqrt(jumpHeight*-2f*gravity);
        velocity.y+=gravity*Time.deltaTime; controller.Move(velocity*Time.deltaTime);
    }
    void Melee()
    {
        if(attackCooldown>0) return; attackCooldown=.45f;
        Vector3 p=attackPoint?attackPoint.position:transform.position+transform.forward*1.2f;
        Collider[] hits=Physics.OverlapSphere(p,attackRange,enemyLayer);
        foreach(Collider c in hits){ Enemy3D e=c.GetComponentInParent<Enemy3D>(); if(e)e.TakeDamage(meleeDamage); }
    }
    void Fireball()
    {
        if(attackCooldown>0 || !fireballPrefab) return; attackCooldown=.65f;
        GameObject go=Instantiate(fireballPrefab,transform.position+transform.forward*1.2f+Vector3.up,Quaternion.LookRotation(transform.forward));
        Projectile3D p=go.GetComponent<Projectile3D>(); if(p){p.damage=fireballDamage;p.direction=transform.forward;}
    }
    public void TakeDamage(int amount){health-=amount;}
    void Respawn(){health=maxHealth;transform.position=new Vector3(0,1,0);}
    void OnDrawGizmosSelected(){Gizmos.DrawWireSphere(attackPoint?attackPoint.position:transform.position+transform.forward*1.2f,attackRange);}
}
