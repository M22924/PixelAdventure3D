using UnityEngine;
public class Projectile3D:MonoBehaviour
{
 public float speed=14f; public int damage=25; public Vector3 direction=Vector3.forward; public float life=4f;
 void Update(){transform.position+=direction.normalized*speed*Time.deltaTime;life-=Time.deltaTime;if(life<=0)Destroy(gameObject);}
 void OnTriggerEnter(Collider other){Enemy3D e=other.GetComponentInParent<Enemy3D>();if(e){e.TakeDamage(damage);Destroy(gameObject);}}
}
