#if UNITY_EDITOR
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
public static class PixelAdventureEditorSetup
{
 [MenuItem("Pixel Adventure/Build Starter Scene")]
 public static void Build(){var scene=EditorSceneManager.NewScene(NewSceneSetup.EmptyScene,NewSceneMode.Single);new GameObject("PixelAdventureBootstrap").AddComponent<PixelAdventureBootstrap>();EditorSceneManager.SaveScene(scene,"Assets/Scenes/PixelAdventure3D.unity");Debug.Log("Pixel Adventure 3D starter scene created.");}
}
#endif
