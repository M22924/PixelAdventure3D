using UnityEngine;
using UnityEngine.UI;

public class PixelAdventureBootstrap : MonoBehaviour
{
 public GameObject playerPrefab, enemyPrefab, bossPrefab, fireballPrefab;
 void Awake(){BuildWorld();}
 void BuildWorld()
 {
  GameObject ground=GameObject.CreatePrimitive(PrimitiveType.Plane);ground.name="Forest_Ground";ground.transform.localScale=new Vector3(6,1,6);
  GameObject p=playerPrefab?Instantiate(playerPrefab):GameObject.CreatePrimitive(PrimitiveType.Capsule);p.name="Hero";p.tag="Player";p.transform.position=new Vector3(0,1,0);if(!p.GetComponent<CharacterController>())p.AddComponent<CharacterController>();Player3D pc=p.GetComponent<Player3D>()??p.AddComponent<Player3D>();
  GameObject cam=new GameObject("Main Camera");Camera c=cam.AddComponent<Camera>();cam.tag="MainCamera";ThirdPersonCamera tc=cam.AddComponent<ThirdPersonCamera>();tc.target=p;pc.cameraTransform=cam.transform;
  GameObject light=new GameObject("Sun");Light l=light.AddComponent<Light>();l.type=LightType.Directional;l.transform.rotation=Quaternion.Euler(50,-30,0);
  if(!enemyPrefab)enemyPrefab=MakeEnemy();if(!bossPrefab)bossPrefab=MakeBoss();if(!fireballPrefab)fireballPrefab=MakeFireball();pc.fireballPrefab=fireballPrefab;
  GameObject mm=new GameObject("MissionManager");MissionManager3D m=mm.AddComponent<MissionManager3D>();m.player=p.transform;m.enemyPrefab=enemyPrefab;m.bossPrefab=bossPrefab;m.spawnRoot=mm.transform;
  BuildUI(m,p);
 }
 GameObject MakeEnemy(){GameObject g=GameObject.CreatePrimitive(PrimitiveType.Capsule);g.name="Enemy";g.AddComponent<Enemy3D>();return g;}
 GameObject MakeBoss(){GameObject g=GameObject.CreatePrimitive(PrimitiveType.Capsule);g.name="Boss";g.transform.localScale=new Vector3(2,2,2);g.AddComponent<Enemy3D>();return g;}
 GameObject MakeFireball(){GameObject g=GameObject.CreatePrimitive(PrimitiveType.Sphere);g.name="Fireball";g.transform.localScale=Vector3.one*.35f;SphereCollider sc=g.GetComponent<SphereCollider>();sc.isTrigger=true;g.AddComponent<Projectile3D>();return g;}
 void BuildUI(MissionManager3D m,GameObject p){GameObject canvas=new GameObject("HUD");Canvas cv=canvas.AddComponent<Canvas>();cv.renderMode=RenderMode.ScreenSpaceOverlay;canvas.AddComponent<CanvasScaler>();canvas.AddComponent<GraphicRaycaster>();m.missionText=MakeText(canvas.transform,new Vector2(20,-20),new Vector2(500,100),20);m.dialogueText=MakeText(canvas.transform,new Vector2(20,-120),new Vector2(700,80),16);m.healthText=MakeText(canvas.transform,new Vector2(-20,-20),new Vector2(220,50),20,true);}
 Text MakeText(Transform parent,Vector2 pos,Vector2 size,int font,bool right=false){GameObject g=new GameObject("Text");g.transform.SetParent(parent);RectTransform r=g.AddComponent<RectTransform>();r.anchorMin=right?new Vector2(1,1):new Vector2(0,1);r.anchorMax=r.anchorMin;r.pivot=right?new Vector2(1,1):new Vector2(0,1);r.anchoredPosition=pos;r.sizeDelta=size;Text t=g.AddComponent<Text>();t.font=Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");t.fontSize=font;t.text="";return t;}
}
