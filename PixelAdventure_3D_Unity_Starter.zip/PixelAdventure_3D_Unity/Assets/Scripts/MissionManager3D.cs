using UnityEngine;
using UnityEngine.UI;
using System.Collections.Generic;

public class MissionManager3D:MonoBehaviour
{
 public DifficultyMode difficulty=DifficultyMode.EASY; public int missionNumber=1; public Text missionText; public Text dialogueText; public Text healthText;
 public GameObject enemyPrefab; public GameObject bossPrefab; public Transform player; public Transform spawnRoot;
 MissionData[] campaign; int requiredKills,kills; bool started;
 void Start(){campaign=PixelAdventureData.BuildCampaign(difficulty);StartMission(1);}
 public void StartMission(int n){missionNumber=Mathf.Clamp(n,1,campaign.Length);MissionData m=campaign[missionNumber-1];kills=0;started=true;requiredKills=m.boss?1:Mathf.Clamp(2+(missionNumber%3),2,4);if(missionText)missionText.text=$"{difficulty}  |  MISSION {missionNumber}/{campaign.Length}\n{m.title}\n{m.objective}\n{m.region}";if(dialogueText)dialogueText.text=m.brief;SpawnMission(m);}
 void SpawnMission(MissionData m){foreach(Transform t in spawnRoot){Destroy(t.gameObject);}if(m.boss){GameObject b=Instantiate(bossPrefab,new Vector3(8,1,8),Quaternion.identity,spawnRoot);Enemy3D e=b.GetComponent<Enemy3D>();e.boss=true;e.maxHealth=300;e.health=300;e.damage=20;e.speed=2f;}else for(int i=0;i<requiredKills;i++){GameObject e=Instantiate(enemyPrefab,new Vector3(4+i*3,1,5+(i%2)*4),Quaternion.identity,spawnRoot);Enemy3D c=e.GetComponent<Enemy3D>();c.maxHealth=50+missionNumber*2;c.health=c.maxHealth;}}
 public void EnemyDefeated(Enemy3D e){kills++;if(campaign[missionNumber-1].boss){CompleteMission();return;}if(kills>=requiredKills)CompleteMission();}
 void CompleteMission(){started=false;if(dialogueText)dialogueText.text="MISSION COMPLETE!";if(missionNumber<campaign.Length)Invoke(nameof(NextMission),1.5f);else if(dialogueText)dialogueText.text="VICTORY! The realm is saved.";}
 void NextMission(){StartMission(missionNumber+1);}
 void Update(){if(healthText&&player){Player3D p=player.GetComponent<Player3D>();if(p)healthText.text=$"HP {p.health}/{p.maxHealth}";}}
}
